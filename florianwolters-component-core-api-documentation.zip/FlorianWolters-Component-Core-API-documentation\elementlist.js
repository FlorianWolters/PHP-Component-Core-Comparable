
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Exception"],["c","FlorianWolters\\Component\\Core\\ClassCastException"],["c","FlorianWolters\\Component\\Core\\ComparableInterface"],["c","FlorianWolters\\Component\\Core\\ComparableUtils"],["c","RuntimeException"]];
